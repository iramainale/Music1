package com.iramain.music

import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            IramainMusicTheme {
                MusicApp()
            }
        }
    }
}

data class MusicTrack(
    val uri: Uri,
    val title: String,
    val artist: String,
    val durationMs: Long
)

private const val PREFS = "iramain_music_prefs"
private const val KEY_LIBRARY = "library_uris"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MusicApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val tracks = remember { mutableStateListOf<MusicTrack>() }
    val player = remember { ExoPlayer.Builder(context).build() }

    var currentIndex by remember { mutableIntStateOf(0) }
    var isPlaying by remember { mutableStateOf(false) }
    var duration by remember { mutableLongStateOf(0L) }
    var position by remember { mutableLongStateOf(0L) }
    var query by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Elegí archivos MP3 o una carpeta de música.") }
    var shuffle by remember { mutableStateOf(false) }
    var repeatMode by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }

    fun buildMediaItem(track: MusicTrack): MediaItem {
        return MediaItem.Builder()
            .setUri(track.uri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(track.title)
                    .setArtist(track.artist)
                    .build()
            )
            .build()
    }

    fun rebuildPlayer(startIndex: Int = 0, playNow: Boolean = false) {
        if (tracks.isEmpty()) return
        val safeIndex = startIndex.coerceIn(0, tracks.lastIndex)
        player.setMediaItems(tracks.map(::buildMediaItem), safeIndex, 0L)
        player.prepare()
        if (playNow) player.play()
    }

    fun importTracks(newTracks: List<MusicTrack>, playFirstImported: Boolean = false) {
        val existing = tracks.map { it.uri.toString() }.toHashSet()
        val unique = newTracks.filter { it.uri.toString() !in existing }
        if (unique.isEmpty()) {
            status = "No se agregaron canciones nuevas."
            return
        }
        val firstNewIndex = tracks.size
        tracks.addAll(unique)
        saveLibrary(context, tracks)
        rebuildPlayer(if (playFirstImported) firstNewIndex else currentIndex, playFirstImported)
        status = "Biblioteca actualizada: ${tracks.size} canciones."
    }

    val pickFiles = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        scope.launch {
            status = "Importando ${uris.size} archivo(s)..."
            val imported = withContext(Dispatchers.IO) {
                uris.mapNotNull { uri ->
                    persistReadPermission(context, uri)
                    readTrackMetadata(context, uri)
                }
            }
            importTracks(imported, playFirstImported = tracks.isEmpty())
        }
    }

    val pickFolder = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri ->
        if (treeUri == null) return@rememberLauncherForActivityResult
        persistReadPermission(context, treeUri)
        scope.launch {
            status = "Escaneando carpeta..."
            val imported = scanFolderForAudio(context, treeUri)
            importTracks(imported, playFirstImported = tracks.isEmpty())
        }
    }

    LaunchedEffect(Unit) {
        val restored = restoreLibrary(context)
        if (restored.isNotEmpty()) {
            tracks.addAll(restored)
            rebuildPlayer(0, playNow = false)
            status = "Biblioteca restaurada: ${tracks.size} canciones."
        }
    }

    LaunchedEffect(player) {
        while (true) {
            currentIndex = max(0, player.currentMediaItemIndex)
            isPlaying = player.isPlaying
            duration = player.duration.takeIf { it > 0 } ?: 0L
            position = player.currentPosition.takeIf { it > 0 } ?: 0L
            delay(500)
        }
    }

    DisposableEffect(Unit) {
        onDispose { player.release() }
    }

    val visibleTracks = tracks.withIndex().filter { indexed ->
        val text = "${indexed.value.title} ${indexed.value.artist}".lowercase()
        text.contains(query.lowercase())
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LibraryMusic, contentDescription = null)
                        Spacer(Modifier.size(8.dp))
                        Text("Iramain Music", fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color(0xFF111318),
                    titleContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF111318), Color(0xFF1C1E26), Color(0xFF101114))
                    )
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                NowPlayingCard(
                    track = tracks.getOrNull(currentIndex),
                    isPlaying = isPlaying,
                    position = position,
                    duration = duration,
                    onSeek = { player.seekTo(it) },
                    onPrevious = { player.seekToPreviousMediaItem() },
                    onPlayPause = {
                        if (tracks.isEmpty()) return@NowPlayingCard
                        if (player.playbackState == Player.STATE_IDLE) rebuildPlayer(currentIndex, false)
                        if (player.isPlaying) player.pause() else player.play()
                    },
                    onNext = { player.seekToNextMediaItem() },
                    shuffle = shuffle,
                    onToggleShuffle = {
                        shuffle = !shuffle
                        player.shuffleModeEnabled = shuffle
                    },
                    repeatMode = repeatMode,
                    onToggleRepeat = {
                        repeatMode = when (repeatMode) {
                            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                            else -> Player.REPEAT_MODE_OFF
                        }
                        player.repeatMode = repeatMode
                    }
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        modifier = Modifier.weight(1f),
                        onClick = { pickFiles.launch(arrayOf("audio/mpeg", "audio/mp3", "audio/*")) }
                    ) {
                        Icon(Icons.Default.UploadFile, contentDescription = null)
                        Spacer(Modifier.size(6.dp))
                        Text("Elegir MP3")
                    }
                    Button(
                        modifier = Modifier.weight(1f),
                        onClick = { pickFolder.launch(null) }
                    ) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null)
                        Spacer(Modifier.size(6.dp))
                        Text("Carpeta")
                    }
                }

                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    label = { Text("Buscar en la biblioteca") },
                    singleLine = true
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = status,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFCBD0DD),
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = {
                        tracks.clear()
                        player.clearMediaItems()
                        saveLibrary(context, tracks)
                        status = "Biblioteca vaciada. Tus archivos no se borraron del celular."
                    }) {
                        Icon(Icons.Default.Delete, contentDescription = "Vaciar biblioteca", tint = Color(0xFFFFB4AB))
                    }
                }

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(visibleTracks, key = { it.value.uri.toString() }) { indexed ->
                        TrackRow(
                            index = indexed.index,
                            track = indexed.value,
                            isCurrent = indexed.index == currentIndex,
                            onClick = {
                                player.seekToDefaultPosition(indexed.index)
                                player.play()
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun NowPlayingCard(
    track: MusicTrack?,
    isPlaying: Boolean,
    position: Long,
    duration: Long,
    onSeek: (Long) -> Unit,
    onPrevious: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    shuffle: Boolean,
    onToggleShuffle: () -> Unit,
    repeatMode: Int,
    onToggleRepeat: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF242734))
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = track?.title ?: "Sin canción seleccionada",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = track?.artist?.takeIf { it.isNotBlank() } ?: "Biblioteca local sin publicidad",
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFFCBD0DD),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Slider(
                value = position.coerceIn(0L, max(duration, 1L)).toFloat(),
                onValueChange = { onSeek(it.toLong()) },
                valueRange = 0f..max(duration, 1L).toFloat()
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(formatTime(position), color = Color(0xFFCBD0DD))
                Text(formatTime(duration), color = Color(0xFFCBD0DD))
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onToggleShuffle) {
                    Icon(
                        Icons.Default.Shuffle,
                        contentDescription = "Aleatorio",
                        tint = if (shuffle) Color(0xFFB7C9FF) else Color.White
                    )
                }
                IconButton(onClick = onPrevious) {
                    Icon(Icons.Default.SkipPrevious, contentDescription = "Anterior", tint = Color.White)
                }
                IconButton(onClick = onPlayPause, modifier = Modifier.size(64.dp)) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = "Play/Pausa",
                        tint = Color.White,
                        modifier = Modifier.size(54.dp)
                    )
                }
                IconButton(onClick = onNext) {
                    Icon(Icons.Default.SkipNext, contentDescription = "Siguiente", tint = Color.White)
                }
                IconButton(onClick = onToggleRepeat) {
                    Icon(
                        imageVector = if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                        contentDescription = "Repetir",
                        tint = if (repeatMode != Player.REPEAT_MODE_OFF) Color(0xFFB7C9FF) else Color.White
                    )
                }
            }
        }
    }
}

@Composable
private fun TrackRow(index: Int, track: MusicTrack, isCurrent: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCurrent) Color(0xFF343B55) else Color(0xFF1F222C)
        )
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(Icons.Default.MusicNote, contentDescription = null, tint = Color(0xFFB7C9FF))
            Column(Modifier.weight(1f)) {
                Text(
                    text = "${index + 1}. ${track.title}",
                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = track.artist.ifBlank { "Archivo local" },
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFCBD0DD),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Text(formatTime(track.durationMs), color = Color(0xFFCBD0DD))
        }
    }
}

@Composable
private fun IramainMusicTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Color(0xFFB7C9FF),
        secondary = Color(0xFFCBD0DD),
        background = Color(0xFF111318),
        surface = Color(0xFF1F222C),
        onPrimary = Color(0xFF122041),
        onSecondary = Color(0xFF22252D),
        onBackground = Color.White,
        onSurface = Color.White
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

private fun saveLibrary(context: Context, tracks: List<MusicTrack>) {
    val encoded = tracks.joinToString("\n") { it.uri.toString() }
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .edit()
        .putString(KEY_LIBRARY, encoded)
        .apply()
}

private suspend fun restoreLibrary(context: Context): List<MusicTrack> = withContext(Dispatchers.IO) {
    val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(KEY_LIBRARY, "")
        .orEmpty()
    raw.lines()
        .filter { it.isNotBlank() }
        .mapNotNull { line -> readTrackMetadata(context, Uri.parse(line)) }
}

private fun persistReadPermission(context: Context, uri: Uri) {
    runCatching {
        context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
}

private suspend fun scanFolderForAudio(context: Context, treeUri: Uri): List<MusicTrack> = withContext(Dispatchers.IO) {
    val root = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext emptyList()
    val output = mutableListOf<MusicTrack>()

    fun walk(file: DocumentFile) {
        if (file.isDirectory) {
            file.listFiles().forEach(::walk)
        } else if (file.isFile && looksLikeAudio(file)) {
            readTrackMetadata(context, file.uri)?.let(output::add)
        }
    }

    walk(root)
    output.sortedBy { it.title.lowercase() }
}

private fun looksLikeAudio(file: DocumentFile): Boolean {
    val name = file.name.orEmpty().lowercase()
    val type = file.type.orEmpty().lowercase()
    return name.endsWith(".mp3") || name.endsWith(".m4a") || name.endsWith(".flac") ||
        name.endsWith(".wav") || type.startsWith("audio/")
}

private fun readTrackMetadata(context: Context, uri: Uri): MusicTrack? {
    val fallbackName = queryDisplayName(context, uri)
        ?.substringBeforeLast('.')
        ?.ifBlank { null }
        ?: "Canción local"

    return runCatching {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                ?.ifBlank { null } ?: fallbackName
            val artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                ?.ifBlank { null } ?: ""
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            MusicTrack(uri = uri, title = title, artist = artist, durationMs = duration)
        } finally {
            retriever.release()
        }
    }.getOrElse {
        MusicTrack(uri = uri, title = fallbackName, artist = "", durationMs = 0L)
    }
}

private fun queryDisplayName(context: Context, uri: Uri): String? {
    return runCatching {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && nameIndex >= 0) cursor.getString(nameIndex) else null
        }
    }.getOrNull()
}

private fun formatTime(ms: Long): String {
    if (ms <= 0L) return "0:00"
    val totalSeconds = ms / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
